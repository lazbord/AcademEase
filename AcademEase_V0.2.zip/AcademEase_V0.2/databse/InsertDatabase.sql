INSERT ALL
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (1, 'John', 'Doe', 'john_doe', 'password1')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (2, 'Jane', 'Smith', 'jane_smith', 'password2')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (3, 'Michael', 'Johnson', 'michael_johnson', 'password3')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (4, 'Emily', 'Williams', 'emily_williams', 'password4')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (5, 'David', 'Brown', 'david_brown', 'password5')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (6, 'Olivia', 'Jones', 'olivia_jones', 'password6')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (7, 'William', 'Garcia', 'william_garcia', 'password7')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (8, 'Sophia', 'Martinez', 'sophia_martinez', 'password8')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (9, 'James', 'Rodriguez', 'james_rodriguez', 'password9')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (10, 'Ava', 'Lopez', 'ava_lopez', 'password10')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (11, 'Alexander', 'Hernandez', 'alexander_hernandez', 'password11')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (12, 'Mia', 'Gonzalez', 'mia_gonzalez', 'password12')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (13, 'Ethan', 'Perez', 'ethan_perez', 'password13')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (14, 'Abigail', 'Torres', 'abigail_torres', 'password14')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (15, 'Daniel', 'Ramirez', 'daniel_ramirez', 'password15')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (16, 'Sophie', 'Flores', 'sophie_flores', 'password16')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (17, 'Logan', 'Ortiz', 'logan_ortiz', 'password17')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (18, 'Charlotte', 'Sanchez', 'charlotte_sanchez', 'password18')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (19, 'Jackson', 'Nguyen', 'jackson_nguyen', 'password19')
    INTO Student (StudentID, FirstName, LastName, Username, Password) VALUES (20, 'Grace', 'Kim', 'grace_kim', 'password20')
SELECT * FROM dual;
  
INSERT INTO University (UniversityID, Name, Username, Password, ProfileImage, Localisation) 
VALUES (1, 'Example University 1', 'uni1_admin', 'uni1pass', NULL, 'Location 1');
INSERT INTO University (UniversityID, Name, Username, Password, ProfileImage, Localisation) 
VALUES (2, 'Example University 2', 'uni2_admin', 'uni2pass', NULL, 'Location 2');
INSERT INTO University (UniversityID, Name, Username, Password, ProfileImage, Localisation) 
VALUES  (3, 'Example University 3', 'uni3_admin', 'uni3pass', NULL, 'Location 3');

INSERT INTO Formation (FormationID, UniversityID, Name, SpaceAvailable) 
VALUES (1, 1, 'Computer Science', 50);
INSERT INTO Formation (FormationID, UniversityID, Name, SpaceAvailable) 
VALUES (2, 1, 'Biology', 30);
INSERT INTO Formation (FormationID, UniversityID, Name, SpaceAvailable) 
VALUES (3, 2, 'Mathematics', 40);
INSERT INTO Formation (FormationID, UniversityID, Name, SpaceAvailable) 
VALUES (4, 2, 'History', 25);
INSERT INTO Formation (FormationID, UniversityID, Name, SpaceAvailable) 
VALUES (5, 3, 'Physics', 35);

INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(1, 1, 1, 0);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES (2, 2, 2, 1);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(3, 3, 3, 2);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(4, 4, 4, 0);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(5, 5, 5, 1);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(6, 6, 1, 2);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(7, 7, 2, 0);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(8, 8, 3, 1);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES (9, 9, 4, 2);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(10, 10, 5, 0);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(11, 11, 1, 1);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(12, 12, 2, 2);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(13, 13, 3, 0);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(14, 14, 4, 1);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(15, 15, 5, 2);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(16, 16, 1, 0);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(17, 17, 2, 1);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(18, 18, 3, 2);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(19, 19, 4, 0);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(20, 20, 5, 1);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(21, 1, 2, 2);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(22, 2, 3, 0);
INSERT INTO FormationForm (FormationFormID, StudentID, FormationID, Status)
VALUES(23, 3, 4, 1);     

