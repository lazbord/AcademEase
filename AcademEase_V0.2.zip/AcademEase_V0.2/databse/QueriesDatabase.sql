SELECT * FROM student;
SELECT * FROM university;
Select * FROM Formation;
SELECT * FROM FormationForm;

SELECT F.Name AS FormationName, U.Localisation, FF.Status AS FormationFormStatus, FF.StudentID
FROM FormationForm FF
JOIN Formation F ON FF.FormationID = F.FormationID
JOIN University U ON F.UniversityID = U.UniversityID;