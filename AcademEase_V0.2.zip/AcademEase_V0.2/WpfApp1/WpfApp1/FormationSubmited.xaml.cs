﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace WpfApp1
{

    public partial class FormationSubmited : Page
    {

        public FormationSubmited()
        {
            InitializeComponent();
            PopulateList();
        }

        public class FormationItem
        {
            public string NomFormation { get; set; }
            public string Localisation { get; set; }
            public string Status { get; set; }
        }

        private void PopulateList()
        {
            List<FormationItem> listOfItems = new List<FormationItem>();

            // Populate the list with FormationItem objects (for demonstration, adding 10 items)
            for (int i = 0; i < 10; i++)
            {
                listOfItems.Add(new FormationItem
                {
                    NomFormation = "Formation " + i,
                    Localisation = "Location " + i,
                    Status = i + "/100"
                    // Set other properties as needed
                });
            }

            // Set the list as the ItemsSource for the ItemsControl
            StackPanelList.ItemsSource = listOfItems;
        }

    }
}
