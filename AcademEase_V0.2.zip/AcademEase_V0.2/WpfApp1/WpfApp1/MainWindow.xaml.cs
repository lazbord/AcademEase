﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;


namespace WpfApp1
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool AllocConsole();

        public User User = new User();
        
        public MainWindow()
        {
            InitializeComponent();
            AllocConsole();
        }

        private void LoginBtn(object sender, RoutedEventArgs e)
        {
            string username = usernamebox.Text;
            string password = passwordbox.Password;

            string connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
                "(CONNECT_DATA=(SID=orcl)));User Id=sys;Password=toupie99;DBA Privilege=SYSDBA;";

            string query = "SELECT * FROM student WHERE username = :Username";

            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                using (OracleCommand command = new OracleCommand(query, connection))
                {
                    command.Parameters.Add("Username", OracleDbType.Varchar2).Value = username;

                    try
                    {
                        connection.Open();
                        OracleDataReader reader = command.ExecuteReader();

                        // Check if a record was found
                        if (reader.Read())
                        {
                            // Retrieve the password from the database
                            string storedPassword = reader.GetString(reader.GetOrdinal("password"));

                            // Compare the stored password with the entered password
                            if (password == storedPassword)
                            {
                                // Get user info
                                string Id = reader.GetString(reader.GetOrdinal("StudentId"));
                                string FirstName = reader.GetString(reader.GetOrdinal("FirstName"));
                                string LastName = reader.GetString(reader.GetOrdinal("LastName"));
                                User.StudentID = Convert.ToInt32(Id);
                                User.FirstName = FirstName;
                                User.LastName = LastName;

                                Console.WriteLine(User.StudentID + User.FirstName + User.LastName);

                                MainApp MainApp = new MainApp();
                                MainApp.Show();
                                this.Hide();
                            }
                            else
                            {
                                Console.WriteLine("Authentication failed: Incorrect password");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Authentication failed: Username not found");
                        }

                        reader.Close();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Authentication failed: Exception - " + ex.Message);
                    }
                }
            }


        }
    }
}
