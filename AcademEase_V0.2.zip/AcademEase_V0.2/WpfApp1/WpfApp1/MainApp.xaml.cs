﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Logique d'interaction pour MainApp.xaml
    /// </summary>
    public partial class MainApp : Window
    {
        public MainApp()
        {
            InitializeComponent();
        }

        private void StudentBtn(object sender, RoutedEventArgs e)
        {
            Student studentPage = new Student();
            MainFrame.Content = studentPage;
        }

        private void FormationSubmittedBtn(object sender, RoutedEventArgs e)
        {
            FormationSubmited formationSubmited = new FormationSubmited();
            MainFrame.Content = formationSubmited;
        }
    }
}
