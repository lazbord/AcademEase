﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class FormationForm
    {
        public int FormationFormId { get; set; }
        public int StudentId { get; set; }
        public int FormationId { get; set; }
        public int Status { get; set; }
        public string Localisation { get; set; }

        public string FormationName { get; set; }



    }
}
