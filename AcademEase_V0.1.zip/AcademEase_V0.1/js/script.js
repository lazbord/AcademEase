function goToRegister() {
    window.location.href = "register.html";
}